#ifndef PERSISTENCIA_H
#define PERSISTENCIA_H

#include "persistencia_palestras.h"
#include "TRANTE_persistencia.h"
#include "localidades_persistencia.h"
#include "calendario.h"



Calendario Monta_Calendario(void);

#endif