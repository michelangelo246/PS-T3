/*          Componente palesTRANTE, módulo de leitura


Realiza a leitura dos dados do arquivo de palestrante. Ou seja, torna disponivel na RAM 
o que esta no arquivo (nao faz tratamento)
--------------------------------------------------------------------------------

*/

#ifndef TRANTE_LEITURA

#define TRANTE_LEITURA

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "TRANTE_auxiliar.h"



TRANTE_cabecalho *Le_palestrantes( FILE *arq_palestrantes );
/* recebe o ponteiro para o arquivo de palestrantes, 
cria a lista de palestrantes e retorna o ponteiro para essa lista.
Em caso de erro, retorna NULL */


#endif
