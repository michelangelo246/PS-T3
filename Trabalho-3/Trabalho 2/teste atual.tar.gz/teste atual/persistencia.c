#include "persistencia.h"
#include "string.h"


#define MIN(a,b) (((a)<(b))?(a):(b))
#define MAX(a,b) (((a)>(b))?(a):(b))


Calendario Monta_Calendario(void)
{	

	FILE* filepalestras = fopen("palestras.txt", "r");
	tipo_disponibilidade_local* d_aux = NULL;
	int inicio;
	int final;
	int i;

	ListaPalestras header_palestras = obter_ListaPalestras(filepalestras);
	TRANTE_cabecalho* header_palestrantes = obter_palestrantes( "palestrantes.txt" );
	tipo_local* header_locais = Pega_Localidade();
	
		// INICIALIZA CALENDARIO
	Calendario c = Cria_Calendario();
	for(i = 1; i < 367; i++)
	{
		c->dias[i] = Cria_Data();
		c->dias[i]->encaixadas = Cria_ListaEventos();
	}

	Aponta_Inicio_ListaPalestras(header_palestras);
	do
	{
		printf("palestra\n");
		Aponta_Inicio_ListaPalestrantes(&header_palestrantes);
		do
		{
			printf("palestante\n");
			if(strcmp(header_palestras->current->p->responsavel, header_palestrantes->current->nome_pessoa ) == 0)
			{
				printf("é o mesmo\n");
				DISP_cabecalho* header_disp = header_palestrantes->current->lista_disp;
				Aponta_Inicio_ListaDisponibilidades(&header_disp);
				do
				{	

					if(header_palestras->current->p->duracao_tratada <=(header_disp->current->hora_fim - header_disp->current->hora_inicio))
					{
						printf("cabe\n");
						while(header_locais->prox)
						{
							printf("\tlocal\n");
							d_aux = header_locais->disponibilidade;
							while(d_aux->prox)
							{
								printf("\n\t\tdia da disp da loc:%d\n\n",d_aux->dia);
								printf("%d >= %d\n",d_aux->duracao,  header_palestras->current->p->duracao_tratada  );
								if(d_aux->duracao >= header_palestras->current->p->duracao_tratada)
								{
									printf("\t\t\tcoube\n");
									if(d_aux->dia == header_disp->current->data)
									{
										printf("\n\n\n\t!!!!!!!!!!!!!!!!!!\n\n");
										inicio = MAX(d_aux->inicio, header_disp->current->hora_inicio);
										final = MIN(d_aux->fim, header_disp->current->hora_fim);

										if(final - inicio >= (header_palestras->current->p->duracao_tratada))
										{
											Evento eaux = Cria_Evento();
											printf("%s \n", header_palestras->current->p->duracao_tratada);
											eaux->nome_palestra = 	strdup(header_palestras->current->p->nome_palestra);
											eaux->nome_palestrante = strdup(header_palestrantes->current->nome_pessoa);
											eaux->nome_local = strdup(header_locais->nome);
											eaux->comeco = inicio;
											eaux->duracao = final - inicio;
											Insere_Inicio_ListaEventos(c->dias[d_aux->dia]->encaixadas, eaux);
										}
									}
								}
								d_aux = d_aux->prox;
							}
							header_locais = header_locais->prox;
						}
					}
					Aponta_Proximo_ListaDisponibilidades(&header_disp);
				}while(header_disp->current != header_disp->last);
			}
			Aponta_Proximo_ListaPalestrantes(&header_palestrantes);
		}while(header_palestrantes->current != header_palestrantes->last);
		Aponta_Proximo_ListaPalestras(header_palestras);
	}
	while(header_palestras->current != header_palestras->last);

}
