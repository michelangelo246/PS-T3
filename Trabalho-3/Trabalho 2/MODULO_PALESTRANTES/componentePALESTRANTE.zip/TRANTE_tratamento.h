/*          Componente palesTRANTE, módulo de tratamento


Recebe a lista de palestrantes gerada pelo modulo de leitura e faz o tratamento.
Especificamente, esse modulo acessa a disponibilidade bruta do palestrante e faz
a conversao para data, hora de inicio e hora de fim.
--------------------------------------------------------------------------------

*/


#ifndef TRANTE_TRATAMENTO

#define TRANTE_TRATAMENTO

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "TRANTE_auxiliar.h"
#include "TRANTE_leitura.h"
#include "TRANTE_tempo.h"


#define MAX_DIA_SEMANA 100
#define MAX_DATA 100
#define MAX_MIN_INICIO 100
#define MAX_MIN_FIM 100
#define MAX_HORA_INICIO 100
#define MAX_HORA_FIM 100



int ConverteDisponibilidadeBruta(TRANTE_cabecalho **header);


int TrataListaPalestrantes(TRANTE_cabecalho **header);
/* Recebe ponteiro para cabecalho da lista de palestrantes
    trata os respectivos dados
    retorna 0 em caso de sucesso
    retorna numero negativo em caso de erro */

    

int Eh_delimitador(char incognita);



#endif
