/******************************************************************************
                         Interface do  TRANTE_AUXILIAR

        Disponibiliza aos modulos de leitura e de tratamento as funcoes para 
    manipular as listas de palestrantes e de disponibilidades

*******************************************************************************/

#ifndef TRANTE_AUXILIAR

#define TRANTE_AUXILIAR


#include <stdio.h>
#include <stdlib.h>




/* Estruturas do componente palestrante */


typedef struct _disponibilidade{

    int data;
    int hora_inicio;
    int hora_fim;
    
    struct _disponibilidade *pnext;
    struct _disponibilidade *pprev;

} disponibilidade;


typedef struct lista_disponibilidade{

    struct _disponibilidade *first;
    struct _disponibilidade *current;
    struct _disponibilidade *last;    

    int qtde_disponibilidade;

} DISP_cabecalho;


typedef struct _palestrante{

    char *nome_pessoa;
    char *disp_bruta;

    struct lista_disponibilidade *lista_disp;

    struct _palestrante *pnext;
    struct _palestrante *pprev;

} palestrante;


typedef struct lista_palestrantes{

    struct _palestrante *first;
    struct _palestrante *current;
    struct _palestrante *last;

    int qtde_palestrante;

} TRANTE_cabecalho;






/* Funções para lista de palestrantes */

TRANTE_cabecalho *Cria_ListaPalestrantes( void );
void Destroi_ListaPalestrantes( TRANTE_cabecalho **header_pointer );

int ListaPalestrantes_Vazia( TRANTE_cabecalho *header );

void Insere_Final_ListaPalestrantes( TRANTE_cabecalho **header_pointer, palestrante *point_pessoa );

int Aponta_Proximo_ListaPalestrantes( TRANTE_cabecalho **header_pointer );
int Aponta_Anterior_ListaPalestrantes( TRANTE_cabecalho **header_pointer );
int Aponta_Inicio_ListaPalestrantes( TRANTE_cabecalho **header_pointer );

int Conta_Pessoas_ListaPalestrantes( TRANTE_cabecalho *header );





/* Funções para lista de DISPONIBILIDADES */



DISP_cabecalho *Cria_ListaDisponibilidades( void );
void Destroi_ListaDisponibilidades( DISP_cabecalho **header_pointer );

int ListaDisponibilidades_Vazia( DISP_cabecalho *header );

void Insere_Final_ListaDisponibilidades( DISP_cabecalho **header_pointer, disponibilidade *point_disp );

int Aponta_Proximo_ListaDisponibilidades( DISP_cabecalho **header_pointer );
int Aponta_Anterior_ListaDisponibilidades( DISP_cabecalho **header_pointer );
int Aponta_Inicio_ListaDisponibilidades( DISP_cabecalho **header_pointer );

int Conta_Disps_ListaDisponibilidades( DISP_cabecalho *header );




#endif



/*    STAND BY 

Palestrante* Info_Corrente_ListaPalestrantes( TRANTE_cabecalho *header );
void Altera_Corrente_ListaPalestrantes( TRANTE_cabecalho *header, palestrante *point_pessoa );
void Limpa_ListaPalestrantes( TRANTE_cabecalho *header );
int Insere_Inicio_ListaPalestrantes(TRANTE_cabecalho header,palestrante *point_pessoa);
int Insere_Corrente_ListaPalestrantes(TRANTE_cabecalho header,palestrante *point_pessoa);
void Aponta_Final_ListaPalestrantes( TRANTE_cabecalho *header );


Palestrante* Remove_Inicio_ListaPalestrantes( TRANTE_cabecalho *header );
Palestrante* Remove_Final_ListaPalestrantes( TRANTE_cabecalho *header );
Palestrante* Remove_Corrente_ListaPalestrantes( TRANTE_cabecalho *header );




Disponibilidade Info_Corrente_ListaDisponibilidade(disponibilidade **header);
void Altera_Corrente_ListaDisponibilidade(disponibilidade **header, Disponibilidade d);
void Limpa_ListaDisponibilidade(disponibilidade **header);
int Insere_Inicio_ListaDisponibilidade(disponibilidade **header,disponibilidade *disp);
int Insere_Corrente_ListaDisponibilidade(disponibilidade **header,disponibilidade *disp);
void Aponta_Final_ListaDisponibilidade(disponibilidade **header);


*/
