#ifndef PERSIST_PALESTRAS_H
#define PERSIST_PALESTRAS_H
#include "listapalestras.h"
#include "palestras_leitura.h"

ListaPalestras obter_ListaPalestras();
#endif