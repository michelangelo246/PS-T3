
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "TRANTE_auxiliar.h"
#include "TRANTE_leitura.h"
#include "TRANTE_tempo.h"
#include "TRANTE_tratamento.h"


TRANTE_cabecalho *obter_palestrantes( char *nome_arq_palestrantes );